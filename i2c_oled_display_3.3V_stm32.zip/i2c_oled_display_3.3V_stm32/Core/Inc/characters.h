/*
 * characters.h
 *
 *  Created on: 1 cze 2023
 *      Author: HP
 */

#ifndef INC_CHARACTERS_H_
#define INC_CHARACTERS_H_


#include "stm32g0xx_hal.h"


uint8_t* Find_Character(uint8_t ch, uint8_t* size);


#endif /* INC_CHARACTERS_H_ */
